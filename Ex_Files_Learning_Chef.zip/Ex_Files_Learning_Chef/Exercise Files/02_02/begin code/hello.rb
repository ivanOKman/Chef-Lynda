file '/hello.txt' do
  content 'Hello, world!'
end